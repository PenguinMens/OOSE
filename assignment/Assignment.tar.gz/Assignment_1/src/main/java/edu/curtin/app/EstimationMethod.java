package edu.curtin.app;

public enum EstimationMethod {
    HIGHEST,
    MEDIAN,
    DEMOCRACY
}
